//
//  ViewController.m
//  HardSDKDemo
//
//  Created by xianfei zou on 2019/11/27.
//  Copyright © 2019 xianfei zou. All rights reserved.
//

#import "ViewController.h"
//#import "HardSDK/HardManagerSDK.h"
#import "HardManagerSDK.h"
#import "SecondViewController.h"
#import "HAMLogOutputWindow.h"
#import "HDWindowLogger.h"

@interface ViewController () <HardManagerSDKDelegate,UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong)NSMutableArray *dataSource;

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setUpTabelView];
//    [[HAMLogOutputWindow sharedInstance]setHidden:NO];
    [HDWindowLogger show];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [HardManagerSDK shareBLEManager].delegate = self;
    
}

#pragma mark - helper handle

-(void)setUpTabelView
{
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
}

#pragma mark - control action

- (IBAction)startScan:(id)sender
{
    [[HardManagerSDK shareBLEManager]scanDevices:@[@"ITPOWER01"]];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    CBPeripheral *device = self.dataSource[indexPath.row];
    cell.textLabel.text = [NSString stringWithFormat:@"%@ --> %@",device.name,device.identifier.UUIDString];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44.f;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    CBPeripheral *device = self.dataSource[indexPath.row];
    
    [[HardManagerSDK shareBLEManager]startConnectDeviceWithUUID:device.identifier.UUIDString];
}

#pragma mark - HardManagerSDKDelegate

-(void)didFindDevice:(CBPeripheral *)device
{
    if (![self.dataSource containsObject:device]) {
        [self.dataSource addObject:device];
        [self.tableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
    }
//    HDNormalLog(@"device == %@",device);
}

- (void)didFindDeviceDict:(NSDictionary *)deviceDict
{
    NSLog(@"deviceDict == %@",deviceDict);
    CBPeripheral *device = deviceDict[@"peripheral"];
    if (![self.dataSource containsObject:device]) {
        [self.dataSource addObject:device];
        [self.tableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
    }
}

-(void)deviceDidConnected
{
    NSLog(@"deviceDidConnected");
    dispatch_async(dispatch_get_main_queue(), ^{
        SecondViewController *second = [[SecondViewController alloc]init];
        second.modalPresentationStyle = UIModalPresentationFullScreen;
        [self presentViewController:second animated:YES completion:nil];
    });
        
}

-(void)deviceDidDisconnected
{
    NSLog(@"deviceDidDisconnected");
}

-(void)settingFallBack:(HardSettingOption)option status:(HardOptionStatus)status
{
    NSString *string = [NSString stringWithFormat:@"settingFallBack %ld status == %ld",(long)option,(long)status];
    HDNormalLog(string);
}

-(void)gettingFallBack:(HardGettingOption)option values:(NSDictionary *)values
{
    NSString *string = [NSString stringWithFormat:@"gettingFallBack %ld %@ ",option,values];
    HDNormalLog(string);
    NSLog(@"gettingFallBack %ld %@ ",option,values);
    if (option == HardGettingExercise) {
        for (HardExerciseModel *model in values[@"exerciseArray"]) {
            NSLog(@"date == %@",model.date);
        }
    }
}

#pragma mark - lazy load

-(NSMutableArray *)dataSource
{
    if (_dataSource == nil) {
        _dataSource = [[NSMutableArray alloc]init];
    }
    return _dataSource;
}

@end
