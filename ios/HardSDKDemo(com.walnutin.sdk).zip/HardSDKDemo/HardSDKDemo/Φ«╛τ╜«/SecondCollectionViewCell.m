//
//  SecondCollectionViewCell.m
//  HardSDKDemo
//
//  Created by xianfei zou on 2019/11/27.
//  Copyright © 2019 xianfei zou. All rights reserved.
//

#import "SecondCollectionViewCell.h"

@implementation SecondCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
