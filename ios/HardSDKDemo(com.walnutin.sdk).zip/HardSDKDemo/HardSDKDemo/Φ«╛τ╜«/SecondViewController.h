//
//  SecondViewController.h
//  HardSDKDemo
//
//  Created by xianfei zou on 2019/11/27.
//  Copyright © 2019 xianfei zou. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SecondViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
