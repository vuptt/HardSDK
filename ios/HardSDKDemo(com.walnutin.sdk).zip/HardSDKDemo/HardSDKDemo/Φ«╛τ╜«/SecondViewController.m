//
//  SecondViewController.m
//  HardSDKDemo
//
//  Created by xianfei zou on 2019/11/27.
//  Copyright © 2019 xianfei zou. All rights reserved.
//

#import "SecondViewController.h"
#import "SecondCollectionViewCell.h"
#import "HardManagerSDK.h"
#import "HardAlarmModel.h"
#import "HDWindowLogger.h"

@interface SecondViewController () <HardManagerSDKDelegate,UICollectionViewDelegate,UICollectionViewDataSource>
{
    NSArray *settingTitles;
    NSArray *gettingTitles;
    
    NSString *targetLanguage;
    NSMutableArray *uiFilesReadySend;
    NSMutableArray *languageFilesReadySend;
}

@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self setUpCollectionView];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [HardManagerSDK shareBLEManager].delegate = self;
    
}

-(void)setUpCollectionView
{
    settingTitles = @[@"设置翻腕",@"复位手环",
               @"设置亮屏时间",@"设置勿扰",@"设置12小时制以及用户信息",@"设置自动心率监测",@"设置全天体温检测",@"设置目标",
               @"设置久坐",@"设置闹钟",@"设置饮水提醒",@"设置消息推送",@"设置温度单位",
               @"设置天气预报",@"设置气压",@"设置节拍器",@"检查固件",@"升级手环",@"开始温度测量",@"开始心率测量",@"开始血压测量",@"开始血氧测量",@"设置语言",@"传缺失UI文件"];
    gettingTitles = @[@"获取电量",@"寻找手环",@"获取步数",@"获取睡眠",@"获取心率",@"获取锻炼",@"获取实时体温",@"获取从2天前开始的体温历史",@"获取从2天前开始的腕温历史"];
    
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    UICollectionViewFlowLayout *flowlayout = [[UICollectionViewFlowLayout alloc]init];
    flowlayout.itemSize = CGSizeMake(screenWidth/4,100.f);
    flowlayout.minimumLineSpacing = CGFLOAT_MIN;
    flowlayout.minimumInteritemSpacing = CGFLOAT_MIN;
    self.collectionView.collectionViewLayout = flowlayout;
    
    [self.collectionView registerNib:[UINib nibWithNibName:@"SecondCollectionViewCell" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:@"cell"];
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 3;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    
    if (section == 0) {

        return settingTitles.count;
    }else if (section == 1) {
        return gettingTitles.count;
    }else{
        return 1;
    }
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    SecondCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    if (indexPath.section == 0) {
        cell.titleLabel.text = settingTitles[indexPath.row];
    }else if (indexPath.section == 1) {
        cell.titleLabel.text = gettingTitles[indexPath.row];
    }else{
        cell.titleLabel.text = @"退出";
        cell.titleLabel.backgroundColor = [UIColor redColor];
    }
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    [collectionView deselectItemAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
        switch (indexPath.row) {
            case 0:
                [[HardManagerSDK shareBLEManager]setHardWristStatus:YES leftHand:YES];
                break;
            case 1:
                [[HardManagerSDK shareBLEManager]setHardRebootAction];
                break;
            case 2:
                [[HardManagerSDK shareBLEManager]setHardScreenOnTime:10];
                break;
            case 3:
                [[HardManagerSDK shareBLEManager]setHardDistrub:YES startTime:600 endTime:1380];
                break;
            case 4:
                [[HardManagerSDK shareBLEManager]setHardTimeUnitAndUserProfileIs12:YES isMeter:YES sex:0 age:20 weight:50 height:180];
                break;
            case 5:
                [[HardManagerSDK shareBLEManager]setHardAutoHeartTest:YES];
                break;
            case 6:
                [[HardManagerSDK shareBLEManager]setHardAllDayTemperature:YES];
                break;
            case 7:
                [[HardManagerSDK shareBLEManager]setHardTarget:2000 calories:500 distance:10000];
                break;
            case 8:
                [[HardManagerSDK shareBLEManager]setHardSedentaryRemindCommand:YES interval:60 startTime:600 endTime:1390 flag:127];
                break;
            case 9:
            {
                HardAlarmModel *model_0 = [[HardAlarmModel alloc]init];
                model_0.alarmID = 0;
                model_0.powerOn = YES;
                model_0.flag = 127;
                model_0.time = 630;
                
                HardAlarmModel *model_5 = [[HardAlarmModel alloc]init];
                model_5.alarmID = 5;
                model_5.powerOn = YES;
                model_5.flag = 63;
                model_5.time = 1244;
                [[HardManagerSDK shareBLEManager]setHardAlarms:@[model_0,model_5]];
            }
                break;
            case 10:
            {
                NSMutableArray *drinkAlarms = [[NSMutableArray alloc]init];
                for (int i = 0 ; i < 8; i++) {
                    HardAlarmModel *model = [[HardAlarmModel alloc]init];
                    model.alarmID = i;
                    model.powerOn = YES;
                    model.flag = 127;
                    model.time = i*120+70;
                    [drinkAlarms addObject:model];
                }
                [[HardManagerSDK shareBLEManager]setHardDrinkAlarm:drinkAlarms];
            }
                break;
            case 11:
                [[HardManagerSDK shareBLEManager]setHardNotificationPhoneCall:YES message:YES qq:YES wechat:YES facebook:YES whatsApp:YES twitter:YES skype:YES line:YES linkedln:YES instagram:YES tim:YES snapchat:YES other:YES];
                break;
            case 12:
                [[HardManagerSDK shareBLEManager]setHardTemperatureType:YES];
                break;
            case 13:
                [[HardManagerSDK shareBLEManager]setHardWeatherSerial:0 date:@"2019-11-28" weatherType:1 temMin:10 temMax:30 wet:30 umbralle:YES];
                break;
            case 14:
                [[HardManagerSDK shareBLEManager]setHardPressure:994];
                break;
            case 15:
                [[HardManagerSDK shareBLEManager]setHardMetronome:180];
                break;
            case 16:
                [[HardManagerSDK shareBLEManager]getHardFirmwareVersionFormServe];
                break;
            case 17:
                [[HardManagerSDK shareBLEManager]getHardFirmwareFileFormServe];
                break;
            case 18:
                [[HardManagerSDK shareBLEManager]setHardBodyTemperatureMeasurement];
                break;
            case 19:
                [[HardManagerSDK shareBLEManager]setStartHeartMeasurement];
                break;
            case 20:
                [[HardManagerSDK shareBLEManager]setStartBloodPressureMeasurement];
                break;
            case 21:
                [[HardManagerSDK shareBLEManager]setStartBloodOxygenMeasurement];
                break;
            case 22:
            {
                NSArray *array = @[@"zh",@"en",@"fr",@"es",@"ru",@"ja",@"pt",@"de",@"it",@"ar"];
                UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"传语言" message:@"请选择传送的语言" preferredStyle:UIAlertControllerStyleActionSheet];
                
                for (NSString *title in array) {
                    [controller addAction:[UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
//                        self->targetLanguage = title;
                        [self readyLanguageFiles:title];
//                        [[HardManagerSDK shareBLEManager]setReadyTransportLanguage:title];
                    }]];
                }
                
                UIViewController *topRootViewController = [UIApplication sharedApplication].keyWindow.rootViewController;
                while (topRootViewController.presentedViewController)
                 {
                    topRootViewController = topRootViewController.presentedViewController;
                 }
                
                [topRootViewController presentViewController:controller animated:YES completion:nil];
                
            }
                break;
            case 23:
                [[HardManagerSDK shareBLEManager]getHardBandImageFileNeeded];
                break;
            default:
                break;
        }
    }
    if (indexPath.section == 1) {
        switch (indexPath.row) {
            case 0:
                [[HardManagerSDK shareBLEManager]getHardBattery];
                break;
            case 1:
                [[HardManagerSDK shareBLEManager]getHardBandAction];
                break;
            case 2:
                [[HardManagerSDK shareBLEManager]getHardStepDaysAgo:0];
                break;
            case 3:
                [[HardManagerSDK shareBLEManager]getHardSleepDaysAgo:0];
                break;
            case 4:
                [[HardManagerSDK shareBLEManager]getHardHeartDaysAgo:0];
                break;
            case 5:
                [[HardManagerSDK shareBLEManager]getHardExerciseWithDate:[NSDate dateWithTimeInterval:-30*24*3600 sinceDate:[NSDate date]]];
                break;
            case 6:
                [[HardManagerSDK shareBLEManager]getHardCurrentTemperature];
                break;
            case 7:
                [[HardManagerSDK shareBLEManager]getHardHistoryBodyTemperature:[NSDate dateWithTimeInterval:-2*24*3600 sinceDate:[NSDate date]]];
                break;
            case 8:
                [[HardManagerSDK shareBLEManager]getHardHistoryRealTemperature:[NSDate dateWithTimeInterval:-2*24*3600 sinceDate:[NSDate date]]];
                break;
            default:
                break;
        }
    }
    if (indexPath.section == 2) {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}

-(void)readyLanguageFiles:(NSString *)language
{
    NSLog(@"传%@",language);
    targetLanguage = language;
    
    NSArray *array = [[NSBundle mainBundle]pathsForResourcesOfType:@"resx" inDirectory:[[NSBundle mainBundle]pathForResource:language ofType:nil]];
    
    languageFilesReadySend = [[NSMutableArray alloc]init];
    
    for (NSString *path in array) {
        if ([path containsString:[@"_"stringByAppendingString:language]]) {
            [languageFilesReadySend addObject:path];
        }
    }
    
    NSLog(@"languageFilesReadySend %ld == %@",languageFilesReadySend.count,languageFilesReadySend);
    [[HardManagerSDK shareBLEManager]setReadyTransportLanguage:language];
}

#pragma mark - HardManagerSDKDelegate

-(void)deviceDidDisconnected
{
    NSLog(@"deviceDidDisconnected");
}

-(void)settingFallBack:(HardSettingOption)option status:(HardOptionStatus)status
{
    NSString *string = [NSString stringWithFormat:@"settingFallBack %ld status == %ld",(long)option,(long)status];
    HDNormalLog(string);
    
    
    
    if (option == HardSettingLanguageTransportReady && status == HardStatusSuccess) {
        NSLog(@"当前剩余%ld条未发送",languageFilesReadySend.count);
        NSString *path = languageFilesReadySend.firstObject;
        [[HardManagerSDK shareBLEManager]setStartTransportLocalFile:path];
    }
    
    
    if (option == HardSettingTransportFile && status == HardStatusSuccess) {
        
        // 这里的判断是判断ui文件的传输回调还是语言文件的传输回调
        if (uiFilesReadySend.count != 0) {
            [uiFilesReadySend removeObjectAtIndex:0];
            if (uiFilesReadySend.count != 0) {
                NSLog(@"当前UI缺失%ld条未发送",uiFilesReadySend.count);
                NSString *path = uiFilesReadySend.firstObject;
                [[HardManagerSDK shareBLEManager]setStartTransportLocalFile:path];
            }else{
                NSLog(@"全部发送完成，再次询问仍有UI文件未传输");
                [[HardManagerSDK shareBLEManager]getHardBandImageFileNeeded];
            }
            
            
        }
        else
        
        if (languageFilesReadySend.count != 0) {
            [languageFilesReadySend removeObjectAtIndex:0];
            if (languageFilesReadySend.count != 0) {
                NSLog(@"当前剩余%ld条未发送",languageFilesReadySend.count);
                NSString *path = languageFilesReadySend.firstObject;
                [[HardManagerSDK shareBLEManager]setStartTransportLocalFile:path];
            }else{
                NSLog(@"全部发送完成");
            }
        }
        
        
    }
}

-(void)gettingFallBack:(HardGettingOption)option values:(NSDictionary *)values
{
    NSString *string = [NSString stringWithFormat:@"gettingFallBack %ld %@ ",option,values];
    HDNormalLog(string);
    NSLog(@"gettingFallBack %ld %@ ",option,values);
    if (option == HardGettingExercise) {
        for (HardExerciseModel *model in values[@"exerciseArray"]) {
            NSLog(@"date == %@",model.date);
        }
    }
    if (option == HardGettingUIFilesNeeded) {
        if ([values[@"files"]count]!=0) {
            uiFilesReadySend = [[NSMutableArray alloc]init];
            for (NSString *uiName in values[@"files"]) {
                NSString *path = [[NSBundle mainBundle]pathForResource:uiName ofType:nil];
                [uiFilesReadySend addObject:path];
            }
            
            NSLog(@"当前UI缺失%ld条未发送",uiFilesReadySend.count);
            NSString *path = uiFilesReadySend.firstObject;
            [[HardManagerSDK shareBLEManager]setStartTransportLocalFile:path];
        }else{
            NSLog(@"手环UI文件已齐全");
        }
    }
}

@end
