package com.walnutin.hardsdktest;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.Gson;
import com.tbruyelle.rxpermissions2.RxPermissions;
import com.walnutin.HeartRateAdditional;
import com.walnutin.hardsdk.ProductList.sdk.GlobalValue;
import com.walnutin.hardsdk.ProductList.sdk.HardSdk;
import com.walnutin.hardsdk.ProductList.sdk.TimeUtil;
import com.walnutin.hardsdk.ProductNeed.Jinterface.SimpleDeviceCallback;
import com.walnutin.hardsdk.ProductNeed.entity.BloodOxygen;
import com.walnutin.hardsdk.ProductNeed.entity.BloodPressure;
import com.walnutin.hardsdk.ProductNeed.entity.Clock;
import com.walnutin.hardsdk.ProductNeed.entity.Drink;
import com.walnutin.hardsdk.ProductNeed.entity.ExerciseData;
import com.walnutin.hardsdk.ProductNeed.entity.HeartRateModel;
import com.walnutin.hardsdk.ProductNeed.entity.SleepModel;
import com.walnutin.hardsdk.ProductNeed.entity.StepInfos;
import com.walnutin.hardsdk.ProductNeed.entity.TempModel;
import com.walnutin.hardsdk.ProductNeed.entity.TempStatus;
import com.walnutin.hardsdk.ProductNeed.entity.Version;
import com.walnutin.hardsdk.ProductNeed.entity.Weather;
import com.walnutin.hardsdk.utils.FileUtil;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.Flowable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;

import static com.walnutin.hardsdk.R.id.content_info;
import static com.walnutin.hardsdk.R.id.time;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener {
    @BindView(R.id.query_bp_btn)
    Button queryBpBtn;
    @BindView(R.id.query_oxygen_btn)
    Button queryOxygenBtn;
    @BindView(R.id.btnBpMeasure)
    Button btnBpMeasure;
    @BindView(R.id.btnOxygenMeasure)
    Button btnOxygenMeasure;
    private String beforeDate;
    private Button searchBtn;
    private Button queryHeartBtn;
    private Button querySleepBtn;
    private Button queryStepBtn;
    private String TAG = MainActivity.class.getSimpleName();
    private EditText contentInfo;
    private final int EDIT_CHANGED = 1;
    private boolean isTestingHeart;
    private Button realHeartBtn;
    private Button sedentaryBtn;
    private Button alarmBtn;
    private Button callPushBtn;
    private Button resetBtn;
    private Button findBattery;
    private Button wristScreen;
    private Button btnCamera;
    private boolean isCalling;
    private Button updateBtn;
    private Button queryVersion;
    private Button resourceTransf;
    private Button btnTiwen;
    private Button btnSwitchTiwen;

    private Button btnQueryBodyTemp;
    private Button btnQueryWanWenTemp;

    private Button btnSyncWanWenTemp;
    private Button btnSyncBodyTemp;
    private Button btnMeasureYeWen;

    private boolean isTestingOxygen;
    private boolean isTestingBp;
    BloodPressure bloodPressure;
    int oxygen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        initView();
        initEvent();
        shenqing();
        //  requestPermission();
    }

    private void requestPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            RxPermissions rxPermissions = new RxPermissions(this);
            rxPermissions.requestEach(Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.ACCESS_NETWORK_STATE,
                    Manifest.permission.ACCESS_WIFI_STATE,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.CALL_PHONE
            )
                    .subscribe(permission -> {

                    });
        }
    }

    private void initView() {
        searchBtn = (Button) findViewById(R.id.search_device_btn);
        queryHeartBtn = (Button) findViewById(R.id.query_heart_btn);
        querySleepBtn = (Button) findViewById(R.id.query_sleep_btn);
        queryStepBtn = (Button) findViewById(R.id.query_step_btn);
        realHeartBtn = (Button) findViewById(R.id.realtime_heart_btn);
        contentInfo = (EditText) findViewById(content_info);
        sedentaryBtn = (Button) findViewById(R.id.set_sedentary_btn);
        alarmBtn = (Button) findViewById(R.id.alarm_btn);
        callPushBtn = (Button) findViewById(R.id.call_push_btn);
        updateBtn = (Button) findViewById(R.id.update_btn);
        resetBtn = (Button) findViewById(R.id.reset_btn);
        findBattery = (Button) findViewById(R.id.findBattery);
        wristScreen = (Button) findViewById(R.id.wristScreen);
        btnCamera = (Button) findViewById(R.id.btnCamera);
        queryVersion = (Button) findViewById(R.id.queryVersion);
        resourceTransf = (Button) findViewById(R.id.resourceTransf);
        btnTiwen = (Button) findViewById(R.id.btnTiwen);
        btnSwitchTiwen = (Button) findViewById(R.id.btnSwitchTiwen);
        btnSyncBodyTemp = (Button) findViewById(R.id.btnSyncBodyTemp);
        btnSyncWanWenTemp = (Button) findViewById(R.id.btnSyncWanWenTemp);
        btnQueryBodyTemp = (Button) findViewById(R.id.btnQueryBodyTemp);
        btnQueryWanWenTemp = (Button) findViewById(R.id.btnQueryWanWenTemp);
        btnMeasureYeWen = (Button) findViewById(R.id.btnMeasureYeWen);

//        btnCall.setOnClickListener(v -> {
//
//            callPhone("17097218091");
//        });
    }

    public void callPhone(String phoneNum) {
        Intent intent = new Intent(Intent.ACTION_CALL);
        Uri data = Uri.parse("tel:" + phoneNum);
        intent.setData(data);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        isVisibleViewed = true;
    }

    @Override
    protected void onPause() {
        super.onPause();
        isVisibleViewed = false;
    }

    private void initEvent() {
        HardSdk.getInstance().setHardSdkCallback(simpleDeviceCallback);

        searchBtn.setOnClickListener(this);
        queryHeartBtn.setOnClickListener(this);
        querySleepBtn.setOnClickListener(this);
        queryStepBtn.setOnClickListener(this);
        realHeartBtn.setOnClickListener(this);
        findBattery.setOnClickListener(this);
        wristScreen.setOnClickListener(this);
        queryVersion.setOnClickListener(this);
        sedentaryBtn.setOnClickListener(this);
        alarmBtn.setOnClickListener(this);
        callPushBtn.setOnClickListener(this);
        updateBtn.setOnClickListener(this);
        resetBtn.setOnClickListener(this);
        btnCamera.setOnClickListener(this);
        resourceTransf.setOnClickListener(this);
        btnTiwen.setOnClickListener(this);
        btnSwitchTiwen.setOnClickListener(this);
        btnQueryWanWenTemp.setOnClickListener(this);
        btnQueryBodyTemp.setOnClickListener(this);
        btnSyncBodyTemp.setOnClickListener(this);
        btnSyncWanWenTemp.setOnClickListener(this);
        btnMeasureYeWen.setOnClickListener(this);


//        findViewById(R.id.readBanben).setOnClickListener(this);
        contentInfo.setOnLongClickListener(v -> {
            contentInfo.setText("");
            return true;
        });


        HardSdk.getInstance().setAccount("user1");

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        currentDate = simpleDateFormat.format(new Date());

        beforeDate = TimeUtil.getBeforeDay(TimeUtil.getCurrentDate(), 0);
    }

    String currentDate;

    @Override
    public void onClick(View view) {
        if (view.getId() != R.id.search_device_btn) {
            if (!HardSdk.getInstance().isDevConnected()) {
                contentInfo.append("请先连接手环后再进行此操作。\n");
                return;
            }
        }

        switch (view.getId()) {
            case R.id.search_device_btn:
                //跳转到新页面搜索和连接
                if (!HardSdk.getInstance().isDevConnected()) {
                    Intent intent = new Intent();
                    intent.setClass(this, SearchDeviceActivity.class);
                    startActivity(intent);
                } else {
                    HardSdk.getInstance().disconnect();
                }

                break;

            case R.id.realtime_heart_btn:
                //开始测试心率
                Log.d(TAG, "onClick: isTestingHeart:" + isTestingHeart);
                if (!isTestingHeart) {
                    HardSdk.getInstance().startRateTest();
                    isTestingHeart = true;
//                    contentInfo.append("爱都手环不支持实时心率测量 开始测量心率：\n");
                    realHeartBtn.setText("停止测试心率");
                } else {
                    HardSdk.getInstance().stopRateTest();
                    isTestingHeart = false;
                    realHeartBtn.setText("开始测试心率");// 倒计时30S APP计时30秒会自动停止
                }

                break;
            case R.id.query_step_btn:
                StepInfos stepInfos = HardSdk.getInstance().queryOneDayStep(TimeUtil.getBeforeDay(TimeUtil.getCurrentDate(), 0));
                stepInfos.getStep();
                contentInfo.append(" 计步：" + new Gson().toJson(stepInfos) + "\n");
                break;
            case R.id.wristScreen:
                contentInfo.append(" 设置翻腕亮屏开 " + "\n");
                HardSdk.getInstance().setWristStatus(true, true);

                break;

            case R.id.query_heart_btn:
                contentInfo.append("查询心率:" + beforeDate + "\n");
                List<HeartRateModel> heartRateModels = HardSdk.getInstance().queryOneDayHeartRate(beforeDate);
                if (heartRateModels != null && heartRateModels.size() > 0) {
                    for (HeartRateModel heartRateModel : heartRateModels) {
                        contentInfo.append(beforeDate + " 心率测试时刻:" + heartRateModel.getTestMomentTime() + " 值： " + heartRateModel.getCurrentRate() + "\n");
                        //其他数据自行从heartRateModel中获取
                    }
                } else {
                    contentInfo.append("没有" + beforeDate + " 心率历史记录" + "\n");
                }
                break;
            case R.id.query_sleep_btn:
                SleepModel sleepModel = HardSdk.getInstance().queryOneDaySleepInfo(beforeDate);
                contentInfo.append(" 睡眠 ：" + new Gson().toJson(sleepModel) + "\n");
                break;
            case R.id.set_sedentary_btn:
                //设置久坐
                HardSdk.getInstance().setSedentaryRemindCommand(1, 60, 1320, 600, 127);  //开关，时间:分钟
                contentInfo.append("设置久坐提醒间隔为60分钟\n");
                break;

            case R.id.queryVersion:
                //设置久坐
                HardSdk.getInstance().queryFirmVesion();  //开关，时间:分钟
                contentInfo.append("查询版本信息 \n");
                break;

            case R.id.findBattery:
                //查找手环
                HardSdk.getInstance().findBattery();//震动次数
                contentInfo.append("查询电量\n");
                break;

            case R.id.alarm_btn:
                //设置闹钟
                int i = TimeUtil.nowHour();
                byte weekper = 127;
                Log.d(TAG, "onClick: weekper" + weekper);
                long timeMillis = (System.currentTimeMillis() + 1000 * 60);
                int hour = TimeUtil.hourFromTimeMillis(timeMillis);
                int minitues = TimeUtil.minituesFromTimeMillis(timeMillis) + 1;
                Log.d(TAG, "onClick: hour:" + hour + " minitues:" + minitues);
                List<Clock> clockList = new ArrayList<>();
                Clock clock = new Clock();
                clock.setEnable(true);
                clock.setTime(String.valueOf(hour + ":" + minitues));
                clock.setRepeat(127);
                clock.setEnable(true);
                clock.setSerial(0);
                clockList.add(clock);
                Clock clock1 = new Clock();
                clock1.setEnable(true);
                clock1.setTime(String.valueOf(hour + ":" + (minitues + 1)));
                clock1.setRepeat(127);
                clock1.setEnable(true);
                clock1.setSerial(1);
                clockList.add(clock1);
                Clock clock2 = new Clock();
                clock2.setEnable(true);
                clock2.setTime(String.valueOf(hour + ":" + (minitues + 2)));
                clock2.setRepeat(127);
                clock2.setEnable(true);
                clock2.setSerial(2);
                clockList.add(clock2);

                HardSdk.getInstance().setAlarmList(clockList);
                contentInfo.append("设置闹钟：" + hour + " 时" + minitues + "分\n");
                break;

            case R.id.call_push_btn:
                //来电提醒
                if (!isCalling) {
                    Log.d(TAG, "onClick: calling:" + 1);
                    HardSdk.getInstance().sendCallOrSmsInToBLE("14334343333", GlobalValue.TYPE_MESSAGE_PHONE, "琅琊榜", "琅琊榜");
                    callPushBtn.setText("挂断电话");
                    isCalling = true;
                    contentInfo.append("推送来电\n");
                } else {
                    Log.d(TAG, "onClick: calling:" + 2);
                    //     HardSdk.getInstance().sendOffHookCommand();
                    HardSdk.getInstance().sendOffHookCommand();
                    callPushBtn.setText("来电通知");
                    isCalling = false;
                    contentInfo.append("停止推送来电\n");
                }
                break;
            case R.id.update_btn:
                //固件升级
                contentInfo.append("执行固件升级\n");

                HardSdk.getInstance().startUpdateBLE();  //在 callback里面接收回调
                break;
            case R.id.resourceTransf:
                //固件升级
                contentInfo.append("传输资源UI文件\n");
                HardSdk.getInstance().startUpgradePicture();  //
                break;
            case R.id.reset_btn:
                //恢复出厂设置
                HardSdk.getInstance().restoreFactoryMode();
                contentInfo.append("执行恢复出厂设置\n");

                break;

            case R.id.btnCamera:
                isOpenCamera = !isOpenCamera;
                contentInfo.append("相机模式 是否开启 " + isOpenCamera + "\n");

                HardSdk.getInstance().openTakePhotoFunc(isOpenCamera);

                if (isOpenCamera) {
                    new Thread(() -> {
                        try {
                            while (isOpenCamera) {
                                Thread.sleep(3000);
                                HardSdk.getInstance().keepTakePhotoState();
                            }
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }).start();
                }
                break;

            case R.id.btnSwitchTiwen: // 开启体温自动测量开关

                HardSdk.getInstance().readTempValue();
                break;

            case R.id.btnSyncBodyTemp: // 开启体温自动测量开关 0代表今天，1代表昨天
                contentInfo.append("开始同步体温 \n");
                HardSdk.getInstance().syncLatestBodyTemperature(0);
                break;

            case R.id.btnSyncWanWenTemp: // 开启体温自动测量开关
                contentInfo.append("开始同步腕温 \n");
                HardSdk.getInstance().syncLatestWristTemperature(0);
                break;

            case R.id.btnQueryBodyTemp: //
                contentInfo.append("开始查询体温 \n");
                List<TempModel> tempModelList = HardSdk.getInstance().getBodyTemperature("2020-04-06", "2020-04-08");
                contentInfo.append("体温结果：\n" + new Gson().toJson(tempModelList) + "\n");
                break;

            case R.id.btnQueryWanWenTemp: //
                contentInfo.append("开始查询腕温 \n");
                List<TempModel> tempModelList2 = HardSdk.getInstance().getWristTemperature("2020-04-06", "2020-04-08");

                contentInfo.append("腕温结果：\n" + new Gson().toJson(tempModelList2) + "\n");
                break;

            case R.id.btnTiwen: // 进入体温测量页面，然后每秒自动读取一次，根据倒计时停止 读取体温
                HardSdk.getInstance().enterTempMeasure();
                if (disposable != null && !disposable.isDisposed()) {
                    disposable.dispose();
                }
                disposable = Flowable.interval(1, 1, TimeUnit.SECONDS).observeOn(AndroidSchedulers.mainThread())
                        .subscribe(v -> {

                            HardSdk.getInstance().readTempValue(); // 读取当前体温值
                        });
                break;

            case R.id.btnMeasureYeWen: // 腋温测量
                isMeasureArmpit = !isMeasureArmpit;
                if (disposable != null && !disposable.isDisposed()) {
                    disposable.dispose();
                }
                // 测量 5分钟 测量开始传0秒开始
                if (isMeasureArmpit == true) {
                    disposable = Flowable.intervalRange(0, 300, 0, 1, TimeUnit.SECONDS).observeOn(AndroidSchedulers.mainThread())
                            .subscribe(v -> {
                                Log.d(TAG, " 倒计时：" + (300 - v));
                                HardSdk.getInstance().measureArmpittem(Math.toIntExact(v));
                            });
                    btnMeasureYeWen.setText("停止测量");
                } else {
                    btnMeasureYeWen.setText("腋温在线测量");
                }

                break;


        }

    }

    boolean isMeasureArmpit;

    Disposable disposable;

    private void shenqing() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            RxPermissions rxPermissions = new RxPermissions(this);
            rxPermissions.requestEach(Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.ACCESS_NETWORK_STATE,
                    Manifest.permission.ACCESS_WIFI_STATE,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.CALL_PHONE

            )
                    .subscribe(permission -> {
                    });
        }
    }


    boolean isOpenCamera = false;

    boolean isVisibleViewed;
    long lastUnLinkTime = 0;


    Version serverVersion = null;
    String version;

    SimpleDeviceCallback simpleDeviceCallback = new SimpleDeviceCallback() {
        @Override
        public void onCallbackResult(int flag, boolean state, Object obj) {
            super.onCallbackResult(flag, state, obj);
            if (flag == GlobalValue.BATTERY) {
                contentInfo.append("电量 ：" + obj + " \n");
            }
            if (flag == GlobalValue.CONNECTED_MSG) {
                Log.d(TAG, "onCallbackResult: 连接成功");
                if (isVisibleViewed)
                    Toast.makeText(getApplicationContext(), "连接成功", Toast.LENGTH_LONG).show();
                searchBtn.setText("断开连接");
                contentInfo.setText("");
            } else if (flag == GlobalValue.DISCONNECT_MSG) {
                Log.d(TAG, "onCallbackResult: 连接失败");
                if (isVisibleViewed) {
                    if (System.currentTimeMillis() / 1000 - lastUnLinkTime / 1000 > 3) {
                        lastUnLinkTime = System.currentTimeMillis();
                        Toast.makeText(getApplicationContext(), "连接断开", Toast.LENGTH_LONG).show();
                    }
                }
                searchBtn.setText("搜索");
            } else if (flag == GlobalValue.CONNECT_TIME_OUT_MSG) {
                Log.d(TAG, "onCallbackResult: 连接超时");
                Toast.makeText(getApplicationContext(), "连接超时", Toast.LENGTH_LONG).show();
                searchBtn.setText("搜索");
            } else if (flag == GlobalValue.STEP_FINISH) {
                Log.d(TAG, "onCallbackResult: 同步计步完成");
                contentInfo.append("同步计步完成\n");
            } else if (flag == GlobalValue.OFFLINE_HEART_SYNC_OK) {
                Log.d(TAG, "onCallbackResult: 同步心率完成");
                contentInfo.append("同步心率完成\n");
            } else if (flag == GlobalValue.SLEEP_SYNC_OK) {
                Log.d(TAG, "onCallbackResult: 同步睡眠完成");
                contentInfo.append("同步睡眠完成 \n");
            } else if (flag == GlobalValue.OFFLINE_EXERCISE_SYNC_OK) {
                Log.d(TAG, "onCallbackResult: 同步锻炼完成");
                contentInfo.append("同步锻炼完成\n");
            } else if (flag == GlobalValue.SYNC_FINISH) {
                Log.d(TAG, "onCallbackResult: 同步完成");
                contentInfo.append("同步完成\n");
                Toast.makeText(getApplicationContext(), "同步完成", Toast.LENGTH_LONG).show();
            } else if (flag == GlobalValue.Firmware_Version) {
                contentInfo.append(" 版本信息： " + obj + " \n");
                version = (String) obj;
            } else if (flag == GlobalValue.Hardware_Version) {
                contentInfo.append(" 硬件版本信息： " + obj + " \n");
            } else if (flag == GlobalValue.DISCOVERY_DEVICE_SHAKE) {
                contentInfo.append("拍照ok 了，\n");

            } else if (flag == GlobalValue.Firmware_DownFile) {
                contentInfo.append(" 下载文件中:   \n");

            } else if (flag == GlobalValue.Firmware_Start_Upgrade) {
                contentInfo.append("开始升级 \n");

            } else if (flag == GlobalValue.Firmware_Info_Error) {
                contentInfo.append("固件版本访问出错，请先获取固件版本  \n");

            } else if (flag == GlobalValue.Firmware_Server_Status) {
                contentInfo.append("是否有新版本: " + obj + " \n");
                if (obj != null) {
                    serverVersion = (Version) obj;
                    contentInfo.append("服务器：" + new Gson().toJson(serverVersion));

                }
            } else if (flag == GlobalValue.Firmware_Upgrade_Progress) {
                contentInfo.append("进度: " + obj + "% \n");

            } else if (flag == GlobalValue.Firmware_Server_Failed) {
                contentInfo.append("未获取到最新 版本信息，请执行 检查新固件 \n");

            }  else if (flag == GlobalValue.READ_TEMP_FINISH_2) { // -273.15代表绝对0度作为无效值
                TempStatus tempStatus = (TempStatus) obj;
                contentInfo.append("温度返回中 体温：.." + tempStatus.bodyTemperature + " 腕温：" + tempStatus.wristTemperature + " 倒计时：" + tempStatus.downTime + " \n");

                if (tempStatus.downTime == 0) {
                    if (disposable != null && !disposable.isDisposed())
                        disposable.dispose();
                }
            } else if (flag == GlobalValue.TEMP_HIGH) { //
                contentInfo.append("温度过高...\n");
            } else if (flag == GlobalValue.SYNC_BODY_FINISH) { //
                contentInfo.append("体温同步完成...\n");
            } else if (flag == GlobalValue.SYNC_WRIST_FINISH) { //
                contentInfo.append("腕温同步完成...\n");
            } else if (flag == GlobalValue.READ_ArmpitTemp) { // -273.15代表绝对0度 作为无效值
                Float yewen = (Float) obj;
                if (!Float.isNaN(yewen) && yewen > -273) {
                    contentInfo.append("腋温值..." + yewen + " \n");
                }
            }else if(flag ==GlobalValue.uiFileListName){

                if(obj ==null){
                    contentInfo.append("不缺ui \n");
                }else {
                    List<String> uiList = (List<String>) obj; // 如果要传ui，将对应缺少的ui集合文件 传给手环，步骤基本同传语言


                }

            }else if(flag ==GlobalValue.PIC_TRANSF_FINISH){
                contentInfo.append("文件  传输完成 \n");

            }else if(flag ==GlobalValue.PIC_TRANSF_START){
                contentInfo.append("文件 开始传输中 \n");
            }else if(flag ==GlobalValue.PIC_TRANSF_ING){
                contentInfo.append("文件 传输中 \n");
            }
        }

        @Override
        public void onStepChanged(int step, float distance, int calories, boolean finish_status) {
            Log.d(TAG, "onStepChanged: step:" + step);
            contentInfo.append("计步：" + step + " 距离:" + distance + " 卡路里：" + calories + "\n");
        }

        @Override
        public void onHeartRateChanged(int rate, int status) {
            super.onHeartRateChanged(rate, status);
            Log.d(TAG, "onHeartRateChanged: status:" + status);
            if (isTestingHeart == true) {
                isTestingHeart = true;
                realHeartBtn.setText("停止测试心率");
                contentInfo.append("实时心率值：" + rate + "\n");
                if (status == GlobalValue.RATE_TEST_FINISH) {
                    contentInfo.append("测量心率结束" + "\n");
                    isTestingHeart = false;
                    realHeartBtn.setText("开始测量心率");
                }
            } else if (isTestingOxygen == true) {
                HeartRateAdditional heartRateAdditional = new HeartRateAdditional(System.currentTimeMillis() / 1000, rate, height, weight, sex, yearOld);
                oxygen = heartRateAdditional.get_blood_oxygen();
                contentInfo.append("实时血氧值：" + oxygen + "\n");
                if (status == GlobalValue.RATE_TEST_FINISH) {
                    contentInfo.append("测量血氧结束" + "\n");
                    isTestingOxygen = false;
                }
            } else if (isTestingBp) {
                HeartRateAdditional heartRateAdditional = new HeartRateAdditional(System.currentTimeMillis() / 1000, rate, height, weight, sex, yearOld);
                bloodPressure = new BloodPressure();
                bloodPressure.systolicPressure = heartRateAdditional.get_systolic_blood_pressure();
                bloodPressure.diastolicPressure = heartRateAdditional.get_diastolic_blood_pressure();
                contentInfo.append("实时血压值：" + bloodPressure.getDiastolicPressure() + "/" + bloodPressure.getSystolicPressure() + "\n");
                if (status == GlobalValue.RATE_TEST_FINISH) {
                    contentInfo.append("测量血压结束" + "\n");
                    isTestingBp = false;
                }
            }
        }
    };


    private int height = 170;
    private int weight = 60;
    private int sex = 0; // 0代表男
    private int yearOld = 30; //

    @Override
    protected void onDestroy() {
        super.onDestroy();
        HardSdk.getInstance().removeHardSdkCallback(simpleDeviceCallback);
    }

    @Override
    public boolean onLongClick(View view) {
        if (view.getId() == content_info) {
            contentInfo.clearComposingText();
        }
        return false;
    }

    @OnClick({R.id.syncStep, R.id.syncSleep, R.id.syncHeart, R.id.syncExercise, R.id.query_exercise_btn, R.id.queryHardVersion, R.id.checkFirmWare, R.id.reset
            , R.id.viewStatus, R.id.wechat})
    public void onViewClicked(View view) {

        if (view.getId() != R.id.search_device_btn) {
            if (!HardSdk.getInstance().isDevConnected()) {
                contentInfo.append("请先连接手环后再进行此操作。\n");
                return;
            }
        }

        switch (view.getId()) {
            case R.id.syncStep:
                HardSdk.getInstance().syncStepData(0);
                break;
            case R.id.syncSleep:
                HardSdk.getInstance().syncSleepData(0);
                break;
            case R.id.syncHeart:
                HardSdk.getInstance().syncHeartRateData(0);
                break;
            case R.id.syncExercise:
                HardSdk.getInstance().syncExerciseData(1574040045000l);//对应 时间2019-11-18 09:20:45，获取该时间后所有锻炼记录
                break;
            case R.id.queryHardVersion:
                HardSdk.getInstance().queryHardVesion();
                break;
            case R.id.checkFirmWare:
                version = "ITPOWER01_1.13.00_200420";
                HardSdk.getInstance().checkNewFirmware(version);
                break;
            case R.id.viewStatus:
                contentInfo.append(" 当前同步状态：" + HardSdk.getInstance().getCurrentSyncState() + "\n");
                contentInfo.append(" 当前dfu 状态：" + HardSdk.getInstance().getCurrentDfuSyncState() + "\n");
                break;
            case R.id.reset:
                HardSdk.getInstance().reset();
                contentInfo.setText(" 复位后 手环一般重启");

                break;
            case R.id.wechat:
                HardSdk.getInstance().sendQQWeChatTypeCommand(GlobalValue.TYPE_MESSAGE_WECHAT, "微信消息来了。。。");
                contentInfo.setText("推送微信消息");
                break;
            case R.id.query_exercise_btn:
                List<ExerciseData> exerciseDataList = HardSdk.getInstance().getExercise(TimeUtil.getYesterdayDate(), TimeUtil.getCurrentDate() + " 23:59:59");
                contentInfo.append("锻炼数据 \n" + new Gson().toJson(exerciseDataList));
                break;


        }
    }

    boolean isHuaShidu = true;

    @OnClick({R.id.setInfo, R.id.btnHeartSwitch, R.id.setWeatherUnit, R.id.setWeatherValue, R.id.setDrinkSit, R.id.setScreen, R.id.setMetronome, R.id.setWuRao, R.id.set_sedentary_btn})
    public void onViewClicked2(View view) {
        if (view.getId() != R.id.search_device_btn) {
            if (!HardSdk.getInstance().isDevConnected()) {
                contentInfo.append("请先连接手环后再进行此操作。\n");
                return;
            }
        }


        switch (view.getId()) {
            case R.id.setInfo:
                contentInfo.append("设置个人信息 \n");
                HardSdk.getInstance().setTimeUnitAndUserProfile(true, true, GlobalValue.SEX_BOY, 20, 60, 172, 140, 90, 180);
                break;
            case R.id.btnHeartSwitch:
                contentInfo.append("开启全天候自动测量心率 \n");
                HardSdk.getInstance().setAutoHealthTest(true);
                break;
            case R.id.setWeatherUnit:
                isHuaShidu = !isHuaShidu;
                if (isHuaShidu) {
                    contentInfo.append("设置天气类型为华氏度 \n");
                    HardSdk.getInstance().setWeatherType(true, GlobalValue.Unit_Fahrenheit);
                } else {
                    contentInfo.append("设置天气类型为摄氏度 \n");
                    HardSdk.getInstance().setWeatherType(true, GlobalValue.Unit_Celsius);
                }


                break;
            case R.id.setWeatherValue:
                contentInfo.append("设置未来5天天气预报 \n");
                List<Weather> weatherList = new ArrayList<>();
                Random random = new Random();
                for (int i = 0; i < 5; i++) {
                    Weather weather = new Weather();
                    weather.high = random.nextInt(20) + 10;
                    weather.low = random.nextInt(10) + 10;
                    weather.serial = i;
                    weather.humidity = 10;
                    weather.isDaisan = 0;
                    weather.time = TimeUtil.getBeforeDay(TimeUtil.getCurrentDate(), -i);
                    Log.d(TAG, "time: " + time);
                    weather.type = random.nextInt(5);
                    weatherList.add(weather);
                }

                HardSdk.getInstance().setWeatherList(weatherList);

                break;
            case R.id.setDrinkSit:
                contentInfo.append("设置喝水提醒 \n");
                List<Drink> drinkList;
                drinkList = new ArrayList<>();
                drinkList.add(new Drink(0, "08:00", true, 127));
                drinkList.add(new Drink(1, "09:30", true, 127));
                drinkList.add(new Drink(2, "11:30", true, 1));
                drinkList.add(new Drink(3, "13:30", false, 64));
                drinkList.add(new Drink(4, "15:30", true, 16));
                drinkList.add(new Drink(5, "17:30", true, 127));
                drinkList.add(new Drink(6, "19:30", true, 127));
                drinkList.add(new Drink(7, "20:30", true, 127));
                HardSdk.getInstance().setDrinkWater(drinkList);
                break;
            case R.id.setScreen:
                contentInfo.append("设置亮屏 5秒 \n");
                HardSdk.getInstance().setScreenOnTime(5);
                break;
            case R.id.setMetronome:
                contentInfo.append("设置节拍器 100 \n");
                HardSdk.getInstance().setMetronome(100);
                break;
            case R.id.setWuRao: //
                contentInfo.append("设置勿扰 关 关闭状态 22点-8点  \n");
                HardSdk.getInstance().setDistrub(false, 1320, 480);
                break;

        }
    }

    @OnClick({R.id.query_bp_btn, R.id.query_oxygen_btn, R.id.btnBpMeasure, R.id.btnOxygenMeasure})
    public void onViewClicked3(View view) {
        switch (view.getId()) {
            case R.id.query_bp_btn: //
                List<HeartRateModel> heartRateModelList = HardSdk.getInstance().queryOneDayOxygen(beforeDate);
                List<BloodPressure> bloodPressureList = new ArrayList<>();

                for (HeartRateModel heartRateModel : heartRateModelList) {
                    try {
                        HeartRateAdditional heartRateAdditional = new HeartRateAdditional(TimeUtil.detaiTimeToStamp(heartRateModel.testMomentTime) / 1000, heartRateModel.currentRate, height, weight, sex, yearOld);
                        BloodPressure bloodPressure = new BloodPressure();
                        bloodPressure.testMomentTime = heartRateModel.testMomentTime;
                        bloodPressure.setSystolicPressure(heartRateAdditional.get_systolic_blood_pressure());
                        bloodPressure.setDiastolicPressure(heartRateAdditional.get_diastolic_blood_pressure());
                        bloodPressureList.add(bloodPressure);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }

                if (bloodPressureList != null && bloodPressureList.size() > 0) {
                    contentInfo.append(beforeDate + " 血压历史:" + new Gson().toJson(bloodPressureList) + "\n");
                } else {
                    contentInfo.append("没有" + beforeDate + " 血压历史记录" + "\n");
                }

                break;
            case R.id.query_oxygen_btn:
                heartRateModelList = HardSdk.getInstance().queryOneDayOxygen(beforeDate);
                List<BloodOxygen> oxygenList = new ArrayList<>();
                for (HeartRateModel heartRateModel : heartRateModelList) {
                    try {
                        HeartRateAdditional heartRateAdditional = new HeartRateAdditional(TimeUtil.detaiTimeToStamp(heartRateModel.testMomentTime) / 1000, heartRateModel.currentRate, height, weight, sex, yearOld);
                        BloodOxygen bloodOxygen = new BloodOxygen();
                        bloodOxygen.testMomentTime = heartRateModel.testMomentTime;
                        bloodOxygen.oxygen = (heartRateAdditional.get_blood_oxygen());
                        oxygenList.add(bloodOxygen);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }

                if (oxygenList != null && oxygenList.size() > 0) {
                    contentInfo.append(beforeDate + " 血氧测试时刻:" + new Gson().toJson(oxygenList) + "\n");
                    //其他数据自行从heartRateModel中获取
                } else {
                    contentInfo.append("没有" + beforeDate + " 血氧历史记录" + "\n");
                }
                break;
            case R.id.btnBpMeasure:
                if (isTestingBp == false) {
                    isTestingBp = true;
                    btnBpMeasure.setText("停止测量");
                    HardSdk.getInstance().startBpMeasure(); // 等待 30秒出值
                } else {
                    isTestingBp = false;
                    btnBpMeasure.setText("开始测量血压");
                    HardSdk.getInstance().stopBpMeasure(bloodPressure);
                }
                break;
            case R.id.btnOxygenMeasure:
                if (isTestingOxygen == false) {
                    isTestingOxygen = true;
                    btnOxygenMeasure.setText("停止测量");
                    HardSdk.getInstance().startBpMeasure(); // 等待 30秒出值
                } else {
                    isTestingOxygen = false;
                    btnOxygenMeasure.setText("开始测量血氧");
                    HardSdk.getInstance().stopOxygenMeasure(oxygen);
                }
                break;
        }
    }

    @OnClick({R.id.btnCheckUi, R.id.btnTransUi, R.id.btnChangeLanguage})
    public void onViewFile(View view) {
//        if (view.getId() != R.id.search_device_btn) {
//            if (!HardSdk.getInstance().isDevConnected()) {
//                contentInfo.append("请先连接手环后再进行此操作。\n");
//                return;
//            }
//        }

        // 传文件 检查 getCurrentDfuSyncState  如果是 GlobalValue.SYNC_IDLE 状态才可以传输，否则dfu通道会阻塞
        contentInfo.append("当前Dfu状态："+HardSdk.getInstance().getCurrentSyncState()+"\n");
        //PIC_TRANSF_ING 文件在传输中， // PIC_TRANSF_START 开始传第一个文件 // PIC_TRANSF_FINISH 文件传输完成，
        switch (view.getId()) {
            case R.id.btnCheckUi:

                contentInfo.append("检查是否缺失UI文件。\n"); //GlobalValue.uiFileListName  data为null代表不需要传ui，否则会返回List<String> 数据
                HardSdk.getInstance().checkUIFile();
                break;
            case R.id.btnTransUi: // 只需要传缺失的ui
                copyFilesFassets(getApplicationContext(),"ui",getExternalFilesDir("ui").getPath());
                List<File> uifileList =  getFileList(getExternalFilesDir("ui").getPath()); // 这里示例是获取全部ui了，只需获取缺失ui的文件列表就好
                HardSdk.getInstance().startTransUI(uifileList);

                break;
            case R.id.btnChangeLanguage:

                copyFilesFassets(getApplicationContext(),"language",getExternalFilesDir("language").getPath());//将assets语言文件拷贝到项目内部存储中

                List<File> fileList =  getFileList(getExternalFilesDir("language/zh").getPath());
                Log.d(TAG,"fileList:"+fileList.size());
                HardSdk.getInstance().startTransLanguage(fileList,"zh"); // 更换为德语, 如果de目录没有，传默认英文en目录给手环
                break;
        }
    }
    List<File> getFileList(String dirPath){
        List<File> stringList = new ArrayList<>();
        File f = new File(dirPath);
        File[] files = f.listFiles();
        if(files != null&& files.length != 0){
            for (File file : files) {
                if (file.isFile()) {
                    stringList.add(file);
                }
            }
        }
        return stringList;
    }



    /**
     *  从assets目录中复制整个文件夹内容
     *  @param  context  Context 使用CopyFiles类的Activity
     *  @param  oldPath  String  原文件路径  如：/aa
     *  @param  newPath  String  复制后路径  如：xx:/bb/cc
     */
    public void copyFilesFassets(Context context, String oldPath, String newPath) {
        try {
            String fileNames[] = context.getAssets().list(oldPath);//获取assets目录下的所有文件及目录名
            if (fileNames.length > 0) {//如果是目录
                File file = new File(newPath);
                file.mkdirs();//如果文件夹不存在，则递归
                for (String fileName : fileNames) {
                    copyFilesFassets(context,oldPath + "/" + fileName,newPath+"/"+fileName);
                }
            } else {//如果是文件
                InputStream is = context.getAssets().open(oldPath);
                FileOutputStream fos = new FileOutputStream(new File(newPath));
                byte[] buffer = new byte[1024];
                int byteCount=0;
                while((byteCount=is.read(buffer))!=-1) {//循环从输入流读取 buffer字节
                    fos.write(buffer, 0, byteCount);//将读取的输入流写入到输出流
                }
                fos.flush();//刷新缓冲区
                is.close();
                fos.close();
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            //如果捕捉到错误则通知UI线程
        }
    }
}
